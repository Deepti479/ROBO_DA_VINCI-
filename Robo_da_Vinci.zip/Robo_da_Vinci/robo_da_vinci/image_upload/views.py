from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
import os

@csrf_exempt
def upload_image(request):
    if request.method == 'GET':
        return render(request, 'upload.html')  # Render the form page

    if request.method == 'POST' and request.FILES.get('image'):
        image = request.FILES['image']
        file_path = os.path.join('media/uploads', image.name)
        
        with default_storage.open(file_path, 'wb+') as destination:
            for chunk in image.chunks():
                destination.write(chunk)

        return JsonResponse({"message": "Image uploaded successfully", "path": file_path})

    return JsonResponse({"error": "Invalid request"}, status=400)
